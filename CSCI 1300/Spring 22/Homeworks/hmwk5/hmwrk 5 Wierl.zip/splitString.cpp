// CSCI 1300 Spring 2022
// Author: Shane Wierl
// Recitation: 105 – Tiffany Phan
// Homework 5 - Problem #4

/*
Algorithm: Split a string into an array of strings at a delimiter character
Save characters of string into a word
At each seperator, end the word and add it to an array
Start a new word and increase the array index
Count every word and return the number of pieces it was split into
*/
#include<iostream>
#include<string>

using namespace std;

int split(string inputString,char separator,string arr[], int size)
{
    int splits = 0; //Counter for every seperation and index of array
    if(inputString == "") //If empty string return 0
        return splits;
    
    string word = ""; //Word
    for(int i = 0; i < inputString.length(); i++) //Loop through string
    {
        if(inputString(i) == separator)//If a separator is found end the word and add it to an array
        {
            if(splits+1 <= size) //Checks for if the number of words is less than the size of the array
            {
                arr[splits] = word; //Creates a word at the index of the array
                word = ""; //Resets the word
                splits++; //Increases the index, and count of seperations
            }
            else //If the number of words is greater than the array size, return -1
            {
                return -1; 
            }
        }
        else //Add the character to a word
        { 
            word += inputString(i);
        }
    }
    return splits+1; //Returns the number of words 
}
