#include<iostream> //input/output stream

using namespace std;

int main() //main function
{
    std::cout << "Hello, world! Hello, CSCI 1300!" << std::endl;
}