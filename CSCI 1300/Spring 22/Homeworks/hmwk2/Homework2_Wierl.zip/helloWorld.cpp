// CSCI 1300 Spring 2022</br>
// Author: Shane Wierl</br>
// Recitation: 105 – Tiffany Phan</br>
// Homework 2 - Problem #1

//Prints "Hello World"

#include<iostream> //input/output stream

using namespace std;

int main() //main function
{
    cout << "Hello, World!" << endl;
    return 0;
}
